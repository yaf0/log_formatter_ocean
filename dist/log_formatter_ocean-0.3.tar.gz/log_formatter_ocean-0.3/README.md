# log_formatter

A simple log formatting utility for Python projects.
